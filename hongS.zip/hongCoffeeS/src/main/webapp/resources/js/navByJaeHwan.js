  let nav = document.querySelectorAll(".nav-link");
  
  nav[1].addEventListener("mouseover", function(){
  	nav[1].style.backgroundColor = "#EFBDBC";
  });
  nav[1].addEventListener("mouseout", function(){
  	nav[1].style.backgroundColor = "";
  });

  nav[2].addEventListener("mouseover", function(){
  	nav[2].style.backgroundColor = "#EFBDBC";
  });
  nav[2].addEventListener("mouseout", function(){
  	nav[2].style.backgroundColor = "";
  });

  nav[5].addEventListener("mouseover", function(){
  	nav[5].style.backgroundColor = "#EFBDBC";
  });
  nav[5].addEventListener("mouseout", function(){
  	nav[5].style.backgroundColor = "";
  });

  nav[8].addEventListener("mouseover", function(){
  	nav[8].style.backgroundColor = "#EFBDBC";
  });
  nav[8].addEventListener("mouseout", function(){
  	nav[8].style.backgroundColor = "";
  });
  
  